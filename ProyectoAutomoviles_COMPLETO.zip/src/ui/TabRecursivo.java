package ui;

import service.AutomovilManager;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class TabRecursivo {
    public JPanel panelRecursivo;
    public JComboBox<String> comboMarcaContar;
    public JButton btnContar;
    public JTextArea textAreaConteo;

    private AutomovilManager manager;

    public TabRecursivo(AutomovilManager manager) {
        this.manager = manager;
        actualizarCombo();

        btnContar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca = (String) comboMarcaContar.getSelectedItem();
                int cantidad = manager.contarPorMarca(marca);
                textAreaConteo.setText("Cantidad de vehículos de marca " + marca + ": " + cantidad);
            }
        });
    }

    private void actualizarCombo() {
        HashSet<String> marcas = new HashSet<>();
        for (var auto : manager.getLista()) {
            marcas.add(auto.getMarca());
        }
        comboMarcaContar.removeAllItems();
        for (String marca : marcas) {
            comboMarcaContar.addItem(marca);
        }
    }
}