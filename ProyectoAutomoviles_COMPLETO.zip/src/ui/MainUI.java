package ui;

import service.AutomovilManager;

import javax.swing.*;

public class MainUI {
    private static AutomovilManager manager = new AutomovilManager();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Gestión de Automóviles");
        JTabbedPane tabbedPane = new JTabbedPane();

        TabIngreso tab1 = new TabIngreso(manager);
        TabFiltrado tab2 = new TabFiltrado(manager);
        TabRecursivo tab3 = new TabRecursivo(manager);

        tabbedPane.add("Ingreso", tab1.panelIngreso);
        tabbedPane.add("Filtrado", tab2.panelFiltrado);
        tabbedPane.add("Recursivo", tab3.panelRecursivo);

        frame.setContentPane(tabbedPane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}