package ui;

import model.Automovil;
import service.AutomovilManager;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TabIngreso {
    public JPanel panelIngreso;
    public JTextArea textAreaMostrar;
    public JButton btnAgregar;
    public JTextField txtCodigo;
    public JTextField txtMarca;
    public JTextField txtModelo;
    public JTextField txtPrecio;

    private AutomovilManager manager;

    public TabIngreso(AutomovilManager manager) {
        this.manager = manager;
        actualizarTextArea();

        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String codigo = txtCodigo.getText().trim();
                String marca = txtMarca.getText().trim();
                String modelo = txtModelo.getText().trim();
                double precio;
                try {
                    precio = Double.parseDouble(txtPrecio.getText().trim());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panelIngreso, "Precio inválido.");
                    return;
                }

                Automovil auto = new Automovil(codigo, marca, modelo, precio);
                manager.agregarOActualizar(auto);
                actualizarTextArea();
            }
        });
    }

    private void actualizarTextArea() {
        StringBuilder sb = new StringBuilder();
        for (Automovil auto : manager.getLista()) {
            sb.append(auto).append("\n");
        }
        textAreaMostrar.setText(sb.toString());
    }
}