package ui;

import model.Automovil;
import service.AutomovilManager;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class TabFiltrado {
    public JPanel panelFiltrado;
    public JComboBox<String> comboMarcaFiltro;
    public JTextField txtPrecioFiltro;
    public JButton btnFiltrar;
    public JTextArea textAreaFiltrado;

    private AutomovilManager manager;

    public TabFiltrado(AutomovilManager manager) {
        this.manager = manager;
        actualizarCombo();

        btnFiltrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca = (String) comboMarcaFiltro.getSelectedItem();
                double precioMin;
                try {
                    precioMin = Double.parseDouble(txtPrecioFiltro.getText().trim());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panelFiltrado, "Precio inválido.");
                    return;
                }

                StringBuilder sb = new StringBuilder();
                for (Automovil auto : manager.filtrarPorMarcaYPrecio(marca, precioMin)) {
                    sb.append(auto).append("\n");
                }
                textAreaFiltrado.setText(sb.toString());
            }
        });
    }

    private void actualizarCombo() {
        HashSet<String> marcas = new HashSet<>();
        for (Automovil auto : manager.getLista()) {
            marcas.add(auto.getMarca());
        }
        comboMarcaFiltro.removeAllItems();
        for (String marca : marcas) {
            comboMarcaFiltro.addItem(marca);
        }
    }
}