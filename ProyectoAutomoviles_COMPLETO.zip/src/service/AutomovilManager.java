package service;

import model.Automovil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AutomovilManager {
    private final ArrayList<Automovil> lista = new ArrayList<>();

    public AutomovilManager() {
        lista.add(new Automovil("A001", "Toyota", "Corolla", 20000));
        lista.add(new Automovil("A002", "Nissan", "Sentra", 18000));
        lista.add(new Automovil("A003", "Toyota", "Yaris", 15000));
        lista.add(new Automovil("A004", "Chevrolet", "Spark", 13000));
    }

    public ArrayList<Automovil> getLista() {
        return lista;
    }

    public void agregarOActualizar(Automovil auto) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCodigo().equals(auto.getCodigo())) {
                lista.set(i, auto);
                return;
            }
        }
        lista.add(auto);
    }

    public ArrayList<Automovil> filtrarPorMarcaYPrecio(String marca, double precioMin) {
        ArrayList<Automovil> resultado = new ArrayList<>();
        for (Automovil auto : lista) {
            if (auto.getMarca().equalsIgnoreCase(marca) && auto.getPrecio() > precioMin) {
                resultado.add(auto);
            }
        }
        resultado.sort(Comparator.comparingDouble(Automovil::getPrecio).reversed());
        return resultado;
    }

    public int contarPorMarca(String marca) {
        return contarRecursivo(marca, 0);
    }

    private int contarRecursivo(String marca, int index) {
        if (index >= lista.size()) return 0;
        int count = lista.get(index).getMarca().equalsIgnoreCase(marca) ? 1 : 0;
        return count + contarRecursivo(marca, index + 1);
    }
}