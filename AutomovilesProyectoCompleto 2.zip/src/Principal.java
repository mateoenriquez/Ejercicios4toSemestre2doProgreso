
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Principal extends JFrame {
    private JPanel panelPrincipal;
    private JTabbedPane tabbedPane1;
    private JTextField codigoField;
    private JTextField marcaField;
    private JTextField modeloField;
    private JTextField precioField;
    private JButton agregarButton;
    private JTextArea ingresoTextArea;
    private JComboBox<String> marcaComboBox;
    private JTextField filtroPrecioField;
    private JButton filtrarButton;
    private JTextArea filtroTextArea;
    private JComboBox<String> marcaContarComboBox;
    private JButton contarButton;
    private JTextArea conteoTextArea;

    private ArrayList<Automovil> listaAutomoviles = new ArrayList<>();
    private ArrayList<Automovil> listaFiltrada = new ArrayList<>();

    public Principal() {
        setContentPane(panelPrincipal);
        setTitle("Gestión de Automóviles");
        setSize(700, 600);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

        // Predefinidos
        listaAutomoviles.add(new Automovil("A1", "Toyota", "Corolla", 25000));
        listaAutomoviles.add(new Automovil("A2", "Mazda", "CX5", 32000));
        listaAutomoviles.add(new Automovil("A3", "Toyota", "Yaris", 18000));
        listaAutomoviles.add(new Automovil("A4", "Ford", "Focus", 22000));
        actualizarTextArea();

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String codigo = codigoField.getText().trim();
                    String marca = marcaField.getText().trim();
                    String modelo = modeloField.getText().trim();
                    double precio = Double.parseDouble(precioField.getText().trim());

                    boolean encontrado = false;
                    for (int i = 0; i < listaAutomoviles.size(); i++) {
                        if (listaAutomoviles.get(i).getCodigo().equalsIgnoreCase(codigo)) {
                            listaAutomoviles.set(i, new Automovil(codigo, marca, modelo, precio));
                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) {
                        listaAutomoviles.add(new Automovil(codigo, marca, modelo, precio));
                    }
                    actualizarTextArea();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Ingrese un precio válido.");
                }
            }
        });

        filtrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String marca = (String) marcaComboBox.getSelectedItem();
                    double precio = Double.parseDouble(filtroPrecioField.getText().trim());
                    listaFiltrada.clear();
                    for (Automovil auto : listaAutomoviles) {
                        if (auto.getMarca().equalsIgnoreCase(marca) && auto.getPrecio() > precio) {
                            listaFiltrada.add(auto);
                        }
                    }
                    Collections.sort(listaFiltrada, new Comparator<Automovil>() {
                        public int compare(Automovil a1, Automovil a2) {
                            return Double.compare(a2.getPrecio(), a1.getPrecio());
                        }
                    });
                    StringBuilder sb = new StringBuilder();
                    for (Automovil a : listaFiltrada) {
                        sb.append(a.toString()).append("\n");
                    }
                    filtroTextArea.setText(sb.toString());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Ingrese un precio válido.");
                }
            }
        });

        contarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca = (String) marcaContarComboBox.getSelectedItem();
                int conteo = contarMarcaRecursivo(marca, listaAutomoviles.size() - 1);
                conteoTextArea.setText("Cantidad de " + marca + ": " + conteo);
            }
        });
    }

    private void actualizarTextArea() {
        StringBuilder sb = new StringBuilder();
        for (Automovil a : listaAutomoviles) {
            sb.append(a.toString()).append("\n");
        }
        ingresoTextArea.setText(sb.toString());

        // Actualizar combobox
        marcaComboBox.removeAllItems();
        marcaContarComboBox.removeAllItems();
        ArrayList<String> marcasUnicas = new ArrayList<>();
        for (Automovil a : listaAutomoviles) {
            if (!marcasUnicas.contains(a.getMarca())) {
                marcasUnicas.add(a.getMarca());
                marcaComboBox.addItem(a.getMarca());
                marcaContarComboBox.addItem(a.getMarca());
            }
        }
    }

    private int contarMarcaRecursivo(String marca, int index) {
        if (index < 0) return 0;
        if (listaAutomoviles.get(index).getMarca().equalsIgnoreCase(marca)) {
            return 1 + contarMarcaRecursivo(marca, index - 1);
        } else {
            return contarMarcaRecursivo(marca, index - 1);
        }
    }

    public static void main(String[] args) {
        new Principal();
    }
}
