
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainGUI extends JFrame {
    private JPanel mainPanel;
    private JTabbedPane tabbedPane;
    private JTextField codigoField;
    private JTextField marcaField;
    private JTextField modeloField;
    private JTextField precioField;
    private JButton agregarActualizarButton;
    private JTextArea displayArea;
    private JComboBox<String> marcaComboBox1;
    private JTextField precioFiltroField;
    private JButton filtrarOrdenarButton;
    private JTextArea filtroArea;
    private JComboBox<String> marcaComboBox2;
    private JButton contarButton;
    private JTextArea conteoArea;

    private ArrayList<Automovil> listaAutomoviles = new ArrayList<>();
    private ArrayList<Automovil> listaFiltrada = new ArrayList<>();

    public MainGUI() {
        setTitle("Gestión de Automóviles");
        setContentPane(mainPanel);
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        // Ingresar 4 automóviles iniciales
        listaAutomoviles.add(new Automovil("A1", "Toyota", "Corolla", 22000));
        listaAutomoviles.add(new Automovil("B2", "Mazda", "CX5", 28000));
        listaAutomoviles.add(new Automovil("C3", "Toyota", "Yaris", 18000));
        listaAutomoviles.add(new Automovil("D4", "Ford", "Focus", 25000));

        actualizarDisplay();

        agregarActualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String codigo = codigoField.getText();
                    String marca = marcaField.getText();
                    String modelo = modeloField.getText();
                    double precio = Double.parseDouble(precioField.getText());

                    Automovil nuevo = new Automovil(codigo, marca, modelo, precio);
                    boolean actualizado = false;

                    for (int i = 0; i < listaAutomoviles.size(); i++) {
                        if (listaAutomoviles.get(i).getCodigo().equals(codigo)) {
                            listaAutomoviles.set(i, nuevo);
                            actualizado = true;
                            break;
                        }
                    }
                    if (!actualizado) listaAutomoviles.add(nuevo);

                    actualizarDisplay();
                    actualizarCombos();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Precio inválido.");
                }
            }
        });

        filtrarOrdenarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String marca = (String) marcaComboBox1.getSelectedItem();
                    double precioMin = Double.parseDouble(precioFiltroField.getText());

                    listaFiltrada.clear();
                    for (Automovil auto : listaAutomoviles) {
                        if (auto.getMarca().equals(marca) && auto.getPrecio() > precioMin) {
                            listaFiltrada.add(auto);
                        }
                    }

                    listaFiltrada.sort(Comparator.comparingDouble(Automovil::getPrecio).reversed());
                    filtroArea.setText("");
                    for (Automovil auto : listaFiltrada) {
                        filtroArea.append(auto + "\n");
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Precio inválido.");
                }
            }
        });

        contarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca = (String) marcaComboBox2.getSelectedItem();
                int count = contarPorMarca(marca, 0);
                conteoArea.setText("Cantidad: " + count);
            }
        });

        actualizarCombos();
    }

    private void actualizarDisplay() {
        displayArea.setText("");
        for (Automovil auto : listaAutomoviles) {
            displayArea.append(auto + "\n");
        }
    }

    private void actualizarCombos() {
        marcaComboBox1.removeAllItems();
        marcaComboBox2.removeAllItems();
        ArrayList<String> marcasUnicas = new ArrayList<>();
        for (Automovil auto : listaAutomoviles) {
            if (!marcasUnicas.contains(auto.getMarca())) {
                marcasUnicas.add(auto.getMarca());
            }
        }
        for (String marca : marcasUnicas) {
            marcaComboBox1.addItem(marca);
            marcaComboBox2.addItem(marca);
        }
    }

    private int contarPorMarca(String marca, int index) {
        if (index >= listaAutomoviles.size()) return 0;
        int suma = listaAutomoviles.get(index).getMarca().equals(marca) ? 1 : 0;
        return suma + contarPorMarca(marca, index + 1);
    }

    public static void main(String[] args) {
        new MainGUI();
    }
}
